<?php

echo json_encode("hello world");

?>